#!/bin/bash
mkdir /opt/print_server
cp ./PrintServer /opt/print_server/
cp ./PrintServer.ini /opt/print_server/
#cp ./PrintServer.prn /opt/print_server/
cp ./PrintServer.sql /opt/print_server/
chmod 755 /opt/print_server -R
chown root:root /opt/print_server -R
cp ./PrintServer.service /lib/systemd/system
chmod 644 /lib/systemd/system/PrintServer.service
chown root:root /lib/systemd/system/PrintServer.service
systemctl daemon-reload
