#!/bin/bash
# 64bit! или будет ошибка фильтра!
sudo cp ./rastertoezpl /usr/lib/cups/filter/rastertoezpl
sudo chown root:root /usr/lib/cups/filter/rastertoezpl
sudo chmod 755 /usr/lib/cups/filter/rastertoezpl
#
sudo mkdir /usr/share/cups/model/GoDEX
sudo cp ./ppd/*.* /usr/share/cups/model/GoDEX/
sudo chown root:root -R /usr/share/cups/model/
sudo chmod 755 -R /usr/share/cups/model/
sudo chmod 644 /usr/share/cups/model/GoDEX/*.*
#
sudo /etc/init.d/cups restart