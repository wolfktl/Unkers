#!/bin/bash
mkdir /opt/print_server
cp -f ./PrintServer /opt/print_server/
cp -f ./PrintServer.ini /opt/print_server/
cp -f ./PrintServer.sql /opt/print_server/
cp -f ./regalias.sh /opt/print_server/
chmod 755 /opt/print_server -R
chown root:root /opt/print_server -R
cp -f ./PrintServer.service /lib/systemd/system
chmod 644 /lib/systemd/system/PrintServer.service
chown root:root /lib/systemd/system/PrintServer.service
systemctl daemon-reload
systemctl start PrintServer
systemctl enable PrintServer
systemctl status PrintServer
