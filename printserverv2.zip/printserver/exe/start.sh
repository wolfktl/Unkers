#!/bin/bash
systemctl start PrintServer
systemctl enable PrintServer.service
