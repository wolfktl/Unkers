#!/bin/bash
mkdir /opt/ssd
cp ./ssd /opt/ssd/
cp ./ssd.ini /opt/ssd/
chmod 755 /opt/ssd -R
chown root:root /opt/ssd -R
cp ./ssd.service /lib/systemd/system
chmod 644 /lib/systemd/system/ssd.service
chown root:root /lib/systemd/system/ssd.service
systemctl daemon-reload
systemctl start ssd
systemctl status ssd
systemctl enable ssd
#Файл .ini - файл настроек, его может не быть, он создастся при первом запуске.
#Папка /opt/ssd/logs/ создается автоматически, в ней хранятся логи (один день - один файл).