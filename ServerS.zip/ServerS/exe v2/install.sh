#!/bin/bash
mkdir /opt/ssd
cp -f ./ssd /opt/ssd/
cp -f ./ssd.ini /opt/ssd/
cp -f ./ssd.sql /opt/ssd/
cp -f ./regalias.sh /opt/ssd/
chmod 755 /opt/ssd -R
chown root:root /opt/ssd -R
cp -f ./ssd.service /lib/systemd/system
chmod 644 /lib/systemd/system/ssd.service
chown root:root /lib/systemd/system/ssd.service
systemctl daemon-reload
systemctl start ssd
systemctl enable ssd
systemctl status ssd
