#!/bin/bash
# 64bit! или будет ошибка фильтра!
sudo cp ./rastertosewoo /usr/lib/cups/filter/rastertosewoo
sudo chown root:root /usr/lib/cups/filter/rastertosewoo
sudo chmod 755 /usr/lib/cups/filter/rastertosewoo
#
sudo mkdir /usr/share/cups/model/SEWOO
sudo cp ./SEWOOLKT.ppd /usr/share/cups/model/SEWOO/SEWOOLKT.ppd
sudo chown root:root -R /usr/share/cups/model/
sudo chmod 755 -R /usr/share/cups/model/
sudo chmod 644 /usr/share/cups/model/SEWOO/SEWOOLKT.ppd
#
sudo /etc/init.d/cups restart