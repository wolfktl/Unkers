sudo cp texttokc commandtokc rastertokc /usr/lib/cups/filter/
